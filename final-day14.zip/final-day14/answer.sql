-- Q1. 정비 기록을 로봇 이름과 함께 보면?
SELECT ml.id, r.name, ML.part, ml.cost, ml.status 
from MAINTENANCE_LOG ML
JOIN robots r ON ml.ROBOT_ID = r.ID -- robots의 로봇이름 name 
order by ml.id;

-- Q2. 로봇별 정비 횟수와 비용 합계
SELECT r.name, count(*) AS works, SUM(ml.cost) AS total_cost
FROM MAINTENANCE_LOG ML
JOIN robots r on ml.ROBOT_ID = r.ID
GROUP BY r.name 
ORDER by total_cost desc;

-- Q3. 정비를 한 번도 받지 않은 로봇은?
SELECT r.name, ml.status
FROM robots r -- 잘못 MAINTENANCE_LOG ML -> 수정
left JOIN MAINTENANCE_LOG ML  ON ml.ROBOT_ID = r.ID 
WHERE ml.ID is null -- 잘못 -> 수정
ORDER by ml.id desc;

-- Q4. 평균 정비 비용보다 비싼 정비는?
SELECT ml.id, r.name, ml.part, ml.cost
FROM MAINTENANCE_LOG ML
JOIN ROBOTS R ON ml.robot_id = r.ID 
WHERE ml.cost > (select AVG(cost) from MAINTENANCE_LOG)
ORDER by ml.cost desc, ml.id;

-- Q5. 대기 중인 정비가 있는 로봇은?
SELECT r.name, r.battery, r.status
FROM ROBOTS R 
WHERE r.ID IN (select ML.ROBOT_ID from MAINTENANCE_LOG ML WHERE status = '대기')
ORDER by r.id;

-- Q6.
begin;

UPDATE maintenance_log SET status = '완료' WHERE robot_id = 6 AND status = '대기' RETURNING id, robot_id, part, status;

UPDATE ROBOTS R SET battery = 100, status = '대기' WHERE id = 6 returning id, name, battery, status;

INSERT into MAINTENANCE_LOG (robot_id, part, cost, MINUTES, work_date) values (6, '베터리', 180000, 50, '2026-11-25')
returning *;

commit;

-- Q7. 정비 상태별 건수와 비용 합은?
SELECT status, count(*) AS works, SUM(cost) AS total_cost 
FROM MAINTENANCE_LOG ml
GROUP by status -- 묶는다. 그룹으로.
order by status;
